import java.util.*;

public class Main {
    static class Room {
        private String roomNumber,block,type;
        Room(String roomNumber,String block,String type){this.roomNumber=roomNumber;this.block=block;this.type=type;}
        public String toString(){return "Room: "+roomNumber+" "+block+" "+type;}
    }
    static class Student {
        private String name,roll,course; private Room room;
        Student(String name,String roll,String course){this.name=name;this.roll=roll;this.course=course;}
        public void setRoom(Room room){this.room=room;}
        public Room getRoom(){return room;}
        public String toString(){return "Student: "+name+" ("+roll+") "+course+"\n"+room;}
    }
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        String[] s=sc.nextLine().split(",",3);
        String[] r=sc.nextLine().split(",",3);
        Student st=new Student(s[0].trim(),s[1].trim(),s[2].trim());
        st.setRoom(new Room(r[0].trim(),r[1].trim(),r[2].trim()));
        System.out.println(st);
    }
}
