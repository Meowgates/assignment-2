import java.util.*;

public class Main {
    static class Product {
        private String productName;
        private double price;
        private int quantity;
        Product(String productName, double price, int quantity) {
            this.productName = productName; this.price = price; this.quantity = quantity;
        }
        public String getProductName() { return productName; }
        public void setProductName(String v) { productName = v; }
        public double getPrice() { return price; }
        public void setPrice(double v) { price = v; }
        public int getQuantity() { return quantity; }
        public void setQuantity(int v) { quantity = v; }
        public double total() { return price * quantity; }
        public String toString() { return productName + " x" + quantity + " = " + format(total()); }
    }
    static class Order {
        private String orderId;
        private List<Product> products = new ArrayList<>();
        Order(String orderId) { this.orderId = orderId; }
        void addProduct(Product p) { products.add(p); }
        double calculateTotal() { double t=0; for(Product p:products)t+=p.total(); return t; }
        public String toString() {
            StringBuilder s = new StringBuilder("Order ID: " + orderId + "\nProducts:\n");
            for(Product p:products) s.append(p).append("\n");
            s.append("Total: ").append(format(calculateTotal()));
            return s.toString();
        }
    }
    static String format(double n) { return n == Math.rint(n) ? String.valueOf((long)n) : String.valueOf(n); }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String id = sc.nextLine().trim();
        int n = Integer.parseInt(sc.nextLine().trim());
        Order o = new Order(id);
        for(int i=0;i<n;i++){
            String[] x=sc.nextLine().split(",");
            o.addProduct(new Product(x[0].trim(), Double.parseDouble(x[1].trim()), Integer.parseInt(x[2].trim())));
        }
        System.out.println(o);
    }
}
