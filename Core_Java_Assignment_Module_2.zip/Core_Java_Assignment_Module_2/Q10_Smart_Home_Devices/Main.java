import java.util.*;

public class Main {
    interface Device { void turnOn(); void turnOff(); }
    static class Fan implements Device {
        public void turnOn(){System.out.println("Fan is now ON");}
        public void turnOff(){System.out.println("Fan is now OFF");}
    }
    static class Light implements Device {
        public void turnOn(){System.out.println("Light is now ON");}
        public void turnOff(){System.out.println("Light is now OFF");}
    }
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        while(sc.hasNextLine()){
            String x=sc.nextLine().trim(); if(x.isEmpty())continue;
            Device d=x.equalsIgnoreCase("Fan")?new Fan():new Light();
            d.turnOn(); d.turnOff();
        }
    }
}
