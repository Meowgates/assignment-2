# CSIT751 Core Java — Module II Practical Home Assignment 1

Solutions for all 15 programming exercises from the supplied assignment PDF.

## Structure
Each question has its own folder containing `Main.java`.

## How to run
Open a terminal inside any question folder:

```bash
javac Main.java
java Main
```

Then enter the input shown in the assignment PDF.

## Questions
1. University – Department – Professor
2. Flight Booking System
3. Employee Payroll System
4. Online Shopping Cart
5. Hospital Management
6. Library – Book – Author
7. Sports League
8. Loan Management System
9. Online Course Platform
10. Smart Home Devices
11. University Hostel Allocation
12. Vehicle Rental System
13. Hotel Reservation System
14. Banking ATM Simulation
15. Passport – Citizen
