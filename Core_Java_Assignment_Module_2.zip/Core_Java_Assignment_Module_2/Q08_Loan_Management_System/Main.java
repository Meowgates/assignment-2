import java.util.*;

public class Main {
    static abstract class Loan {
        protected double principal, rate, time;
        Loan(double principal,double rate,double time){this.principal=principal;this.rate=rate;this.time=time;}
        abstract double calculateInterest();
    }
    static class HomeLoan extends Loan {
        HomeLoan(double p,double t){super(p,8,t);}
        double calculateInterest(){return principal*rate*time/100;}
    }
    static class CarLoan extends Loan {
        CarLoan(double p,double t){super(p,10,t);}
        double calculateInterest(){return principal*rate*time/100;}
    }
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        while(sc.hasNextLine()){
            String line=sc.nextLine().trim(); if(line.isEmpty())continue;
            String[] x=line.split(",");
            double p=Double.parseDouble(x[1].trim()), t=Double.parseDouble(x[2].trim());
            Loan l=x[0].trim().equalsIgnoreCase("Home")?new HomeLoan(p,t):new CarLoan(p,t);
            System.out.println(x[0].trim()+" Loan Interest: "+l.calculateInterest());
        }
    }
}
