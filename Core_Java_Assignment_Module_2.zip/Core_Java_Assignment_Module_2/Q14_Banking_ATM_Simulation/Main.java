import java.util.*;

public class Main {
    static class Account {
        private String accNo,holderName; private double balance;
        Account(String accNo,String holderName){this.accNo=accNo;this.holderName=holderName;}
        void deposit(double amount){balance+=amount;System.out.println("Deposited: "+amount);}
        void withdraw(double amount){
            if(amount<=balance){balance-=amount;System.out.println("Withdrawn: "+amount);}
            else System.out.println("Insufficient balance");
        }
        double getBalance(){return balance;}
    }
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int n=Integer.parseInt(sc.nextLine().trim());
        Account a=new Account("ATM001","User");
        for(int i=0;i<n;i++){
            String[] x=sc.nextLine().trim().split("\\s+");
            if(x[0].equalsIgnoreCase("deposit"))a.deposit(Double.parseDouble(x[1]));
            else if(x[0].equalsIgnoreCase("withdraw"))a.withdraw(Double.parseDouble(x[1]));
            else if(x[0].equalsIgnoreCase("getBalance"))System.out.println("Balance: "+a.getBalance());
        }
    }
}
