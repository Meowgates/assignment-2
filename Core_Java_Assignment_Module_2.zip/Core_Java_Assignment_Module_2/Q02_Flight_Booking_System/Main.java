import java.util.*;

public class Main {
    static abstract class Flight {
        private String flightNumber, airline;
        private double fare;
        Flight(String flightNumber, String airline, double fare) {
            this.flightNumber = flightNumber; this.airline = airline; this.fare = fare;
        }
        protected double getFare() { return fare; }
        public abstract double calculateFare();
        public String toString() {
            return "Flight No: " + flightNumber + " Airline: " + airline + " Fare: " + calculateFare();
        }
    }
    static class DomesticFlight extends Flight {
        DomesticFlight(String n, String a, double f) { super(n, a, f); }
        public double calculateFare() { return getFare() * 1.10; }
    }
    static class InternationalFlight extends Flight {
        InternationalFlight(String n, String a, double f) { super(n, a, f); }
        public double calculateFare() { return getFare() * 1.25; }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (sc.hasNextLine()) {
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            String[] x = line.split(",", 4);
            Flight f = x[0].trim().equalsIgnoreCase("Domestic")
                    ? new DomesticFlight(x[1].trim(), x[2].trim(), Double.parseDouble(x[3].trim()))
                    : new InternationalFlight(x[1].trim(), x[2].trim(), Double.parseDouble(x[3].trim()));
            System.out.println(f);
        }
    }
}
