import java.util.*;

public class Main {
    static class Employee {
        protected String name, id;
        protected double basicSalary;
        Employee() {}
        Employee(String name, String id, double basicSalary) {
            this.name = name; this.id = id; this.basicSalary = basicSalary;
        }
        public double calculateSalary() { return basicSalary; }
        public String toString() {
            return "Employee " + name + " (" + id + ") Salary: " + calculateSalary();
        }
    }
    static class Manager extends Employee {
        private double bonus;
        Manager(String name, String id, double basicSalary, double bonus) {
            super(name, id, basicSalary); this.bonus = bonus;
        }
        public double calculateSalary() { return basicSalary + bonus; }
        public String toString() {
            return "Manager " + name + " (" + id + ") Salary: " + calculateSalary();
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (sc.hasNextLine()) {
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            String[] x = line.split(",");
            Employee e;
            if (x[0].trim().equalsIgnoreCase("Manager"))
                e = new Manager(x[1].trim(), x[2].trim(), Double.parseDouble(x[3].trim()), Double.parseDouble(x[4].trim()));
            else
                e = new Employee(x[1].trim(), x[2].trim(), Double.parseDouble(x[3].trim()));
            System.out.println(e);
        }
    }
}
